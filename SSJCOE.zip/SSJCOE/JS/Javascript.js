function MenuHover(a){
	a.style.color = "black";
}

function MenuNormal(a){
	a.style.color = "#006699";
}

function OnSubmit(){
	alert("Your Message has been sent! We will get back to you.");
}


function OnSignUp(){
		if(document.getElementById("acceptTerms").checked){
				document.getElementById("submitbutton").disabled= false;
		}
		else{
			document.getElementById("submitbutton").disabled= true;
		}
}

displayCD(0);

function displayCD(i) {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            myFunction(this, i);
        }
    };
    xmlhttp.open("GET", "exam.xml", true);
    xmlhttp.send();
}

function myFunction(xml, i) {
    var xmlDoc = xml.responseXML; 
    x = xmlDoc.getElementsByTagName("CD");
    document.getElementById("showCD").innerHTML =
    "Artist: " +
    x[i].getElementsByTagName("ARTIST")[0].childNodes[0].nodeValue +
    "<br>Title: " +
    x[i].getElementsByTagName("TITLE")[0].childNodes[0].nodeValue +
    "<br>Year: " + 
    x[i].getElementsByTagName("YEAR")[0].childNodes[0].nodeValue;
}